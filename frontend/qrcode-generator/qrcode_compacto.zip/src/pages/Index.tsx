import QRCodeGenerator from "../components/QRCodeGenerator";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-charcoal-950 to-black">
      <QRCodeGenerator />
    </div>
  );
};

export default Index;
